# Copyright (c) OpenMMLab. All rights reserved.
from .hub import get_config, get_model

__all__ = ['get_config', 'get_model']
